#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/beast/version.hpp>
#include <boost/asio.hpp>
#include <boost/process/v1.hpp>
#include <nlohmann/json.hpp>

#include <regex>
#include <iostream>
#include <fstream>
#include <string>
#include <thread>
#include <vector>
#include <stdexcept>
#include <chrono>
#include <atomic>
#include <cstdio>
#include <filesystem>
#include <ctime>
#include <mutex>

namespace beast = boost::beast;
namespace http = beast::http;
namespace net = boost::asio;
namespace bp = boost::process::v1;
namespace fs = std::filesystem;
using json = nlohmann::json;
using tcp = net::ip::tcp;

// --------------------------------------------------
// Global defaults
// --------------------------------------------------
// const std::string INSTALL_DIR = "/opt/vigenflow";

std::string g_model_id = "flux.2-klein-4B"; // Default model name
// std::string g_weights_path    = INSTALL_DIR + "/"; 
// std::string g_npu_base_dir    = INSTALL_DIR + "/npu_files";
// std::string g_exe_base_dir    = INSTALL_DIR + "/exe_models";
// std::string g_custom_exe      = ""; // Used if overridden by -e flag
// std::string g_workdir         = INSTALL_DIR; 

std::string g_weights_path = "./";
std::string g_npu_base_dir = "../npu_files"; 
std::string g_exe_base_dir = "../exe_models"; 
std::string g_custom_exe      = ""; // Used if overridden by -e flag
std::string g_workdir = ".";

unsigned short g_port = 11283;
std::string g_public_base_url = "http://127.0.0.1:" + std::to_string(g_port);
std::string g_output_dir = "../images";

bool g_keep_images = true; 
std::mutex g_infer_mutex;

// --------------------------------------------------
// Params
// --------------------------------------------------
struct GenParams {
    int H = 1024;
    int W = 1024;
    int steps = 4;
    int seed = 42;
    std::string model = ""; 
    std::string prompt = "Young Chinese woman in red Hanfu, intricate embroidery. Impeccable makeup...";
    std::vector<std::string> input_images; // Holds paths to uploaded edit images
};

// --------------------------------------------------
// Helpers
// --------------------------------------------------
static void ensure_output_dir() {
    std::error_code ec;
    fs::create_directories(g_output_dir, ec);
    if (ec) {
        throw std::runtime_error("Failed to create output dir: " + g_output_dir + " : " + ec.message());
    }
}

static bool is_safe_filename(const std::string& name) {
    if (name.empty()) return false;
    if (name.find("..") != std::string::npos) return false;
    if (name.find('/') != std::string::npos) return false;
    if (name.find('\\') != std::string::npos) return false;
    return true;
}

static std::vector<char> read_binary_file(const std::string& path) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) {
        throw std::runtime_error("cannot open file: " + path);
    }
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    std::vector<char> data(static_cast<size_t>(size));
    if (size > 0 && !file.read(data.data(), size)) {
        throw std::runtime_error("failed to read file: " + path);
    }
    return data;
}

static std::string base64_encode(const std::vector<char>& data) {
    static const char table[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";
    std::string out;
    out.reserve(((data.size() + 2) / 3) * 4);
    size_t i = 0;
    const unsigned char* bytes = reinterpret_cast<const unsigned char*>(data.data());
    const size_t len = data.size();
    while (i + 2 < len) {
        unsigned int n = (static_cast<unsigned int>(bytes[i]) << 16) |
                         (static_cast<unsigned int>(bytes[i + 1]) << 8) |
                         static_cast<unsigned int>(bytes[i + 2]);
        out.push_back(table[(n >> 18) & 63]);
        out.push_back(table[(n >> 12) & 63]);
        out.push_back(table[(n >> 6) & 63]);
        out.push_back(table[n & 63]);
        i += 3;
    }
    if (i < len) {
        unsigned int n = static_cast<unsigned int>(bytes[i]) << 16;
        out.push_back(table[(n >> 18) & 63]);
        if (i + 1 < len) {
            n |= static_cast<unsigned int>(bytes[i + 1]) << 8;
            out.push_back(table[(n >> 12) & 63]);
            out.push_back(table[(n >> 6) & 63]);
            out.push_back('=');
        } else {
            out.push_back(table[(n >> 12) & 63]);
            out.push_back('=');
            out.push_back('=');
        }
    }
    return out;
}

static std::string get_response_format(const std::string& body) {
    try {
        json j = json::parse(body);
        if (j.contains("response_format") && j["response_format"].is_string()) {
            return j["response_format"].get<std::string>();
        }
    } catch (...) {}
    return "b64_json";
}

// --------------------------------------------------
// Parse Standard JSON Request (Generations)
// --------------------------------------------------
GenParams parse_request(const std::string& body)
{
    std::cout << "========== RAW HTTP BODY ==========\n";
    std::cout << body << "\n";
    std::cout << "===================================\n";

    GenParams params;
    params.model = g_model_id; 

    try {
        json j = json::parse(body);

        if (j.contains("model") && j["model"].is_string()) params.model = j["model"].get<std::string>();
        if (j.contains("prompt") && j["prompt"].is_string()) params.prompt = j["prompt"].get<std::string>();
        if (j.contains("steps") && j["steps"].is_number_integer()) params.steps = j["steps"].get<int>();
        if (j.contains("seed") && j["seed"].is_number_integer()) params.seed = j["seed"].get<int>();

        if (j.contains("size") && j["size"].is_string()) {
            std::string size = j["size"].get<std::string>();
            if (size == "3:4" || size == "768x1024") { params.W = 768; params.H = 1024; }
            else if (size == "4:3" || size == "1024x768") { params.W = 1024; params.H = 768; }
            else if (size == "9:16" || size == "576x1024") { params.W = 576; params.H = 1024; }
            else if (size == "16:9" || size == "1024x576") { params.W = 1024; params.H = 576; }
            else if (size == "1:1" || size == "1024x1024") { params.W = 1024; params.H = 1024; }
            else if (size == "1024x1536") { params.W = 1024; params.H = 1536; }
            else if (size == "1536x1024") { params.W = 1536; params.H = 1024; }
        }
        return params;
    }
    catch (...) {}

    // Fallback regex parsing
    if (body.find("3:4") != std::string::npos) { params.H = 1024; params.W = 768; }
    else if (body.find("4:3") != std::string::npos) { params.H = 768; params.W = 1024; }
    else if (body.find("9:16") != std::string::npos) { params.H = 1024; params.W = 576; }
    else if (body.find("16:9") != std::string::npos) { params.H = 576; params.W = 1024; }
    else if (body.find("1:1") != std::string::npos) { params.H = 1024; params.W = 1024; }

    std::regex steps_regex(R"("steps"\s*:\s*(\d+))");
    std::smatch match_steps;
    if (std::regex_search(body, match_steps, steps_regex)) params.steps = std::stoi(match_steps[1].str());

    std::regex seed_regex(R"("seed"\s*:\s*(\d+))");
    std::smatch match_seed;
    if (std::regex_search(body, match_seed, seed_regex)) params.seed = std::stoi(match_seed[1].str());

    std::string prompt_key = "\"prompt\":";
    size_t p_key_pos = body.find(prompt_key);
    if (p_key_pos != std::string::npos) {
        size_t v_start = body.find("\"", p_key_pos + prompt_key.length());
        size_t v_end = body.find("\"", v_start + 1);
        if (v_start != std::string::npos && v_end != std::string::npos) {
            params.prompt = body.substr(v_start + 1, v_end - v_start - 1);
        }
    }
    return params;
}

// --------------------------------------------------
// Parse Multipart Request (For Image Edits)
// --------------------------------------------------
GenParams parse_multipart_request(const http::request<http::string_body>& req) {
    GenParams params;
    params.model = g_model_id; 
    ensure_output_dir();

    std::string content_type(req[http::field::content_type]);
    std::string boundary;
    auto pos = content_type.find("boundary=");
    if (pos != std::string::npos) {
        boundary = "--" + content_type.substr(pos + 9);
    } else {
        throw std::runtime_error("Missing multipart boundary");
    }

    const std::string& body = req.body();
    size_t start_pos = 0;

    while ((start_pos = body.find(boundary, start_pos)) != std::string::npos) {
        start_pos += boundary.length();
        if (body.compare(start_pos, 2, "--") == 0) break; // End of form
        start_pos += 2; // Skip \r\n

        size_t header_end = body.find("\r\n\r\n", start_pos);
        if (header_end == std::string::npos) break;

        std::string headers = body.substr(start_pos, header_end - start_pos);
        size_t body_start = header_end + 4;
        size_t next_boundary = body.find(boundary, body_start);
        if (next_boundary == std::string::npos) break;

        // Actual part data
        size_t data_len = (next_boundary > body_start + 2) ? (next_boundary - body_start - 2) : 0;
        std::string part_data = body.substr(body_start, data_len);

        std::smatch match;
        if (std::regex_search(headers, match, std::regex("name=\"([^\"]+)\""))) {
            std::string name = match[1].str();

            if (name == "prompt") {
                params.prompt = part_data;
            } else if (name == "size") {
                std::string size = part_data;
                if (size == "3:4" || size == "768x1024") { params.W = 768; params.H = 1024; }
                else if (size == "4:3" || size == "1024x768") { params.W = 1024; params.H = 768; }
                else if (size == "9:16" || size == "576x1024") { params.W = 576; params.H = 1024; }
                else if (size == "16:9" || size == "1024x576") { params.W = 1024; params.H = 576; }
                else if (size == "1:1" || size == "1024x1024") { params.W = 1024; params.H = 1024; }
            } else if (name == "model") {
                params.model = part_data; 
            } else if (name == "image[]" || name == "image") {
                auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::system_clock::now().time_since_epoch()
                ).count();
                
                std::string tmp_filename = "upload_" + std::to_string(ms) + "_" + std::to_string(params.input_images.size()) + ".png";
                std::string save_path = (fs::path(g_output_dir) / tmp_filename).string();

                std::ofstream out(save_path, std::ios::binary);
                out.write(part_data.data(), part_data.size());
                out.close();

                std::cout << "[INFO] Received and saved input image: " << save_path << "\n";
                params.input_images.push_back(save_path);
            }
        }
        start_pos = next_boundary;
    }
    return params;
}

// --------------------------------------------------
// Run worker
// --------------------------------------------------
std::string run_worker(const GenParams& p)
{
    ensure_output_dir();

    // 1) Find out what model we REALLY want to run
    std::string raw_target = p.model;
    
    // If the UI sends a generic default name, override it with the server's booted model
    if (raw_target == "local-model-1" || raw_target == "edit_model" || raw_target == "local_model_npu" || raw_target.empty()) {
    raw_target = g_model_id;
}

    // Normalize ":edit" to "-edit" just in case the UI or user sends it that way
    size_t colon_pos = raw_target.find(":edit");
    if (colon_pos != std::string::npos) {
        raw_target.replace(colon_pos, 5, "-edit");
    }

    std::string req_npu_files_path;
    std::string req_exe_path;

    // 2) Explicit Routing Rules 
    if (raw_target == "flux.2-klein-4B-edit") {
        // NPU is base, EXE gets the edit folder
        req_npu_files_path = g_npu_base_dir + "/flux.2-klein-4B";
        req_exe_path = g_exe_base_dir + "/flux.2-klein-4B-edit/run.exe";
    } 
    else if (raw_target == "flux.2-klein-4B") {
        req_npu_files_path = g_npu_base_dir + "/flux.2-klein-4B";
        req_exe_path = g_exe_base_dir + "/flux.2-klein-4B/run.exe";
    }
    else {
        // Fallback for z-image-turbo (NPU and EXE folders match exactly)
        req_npu_files_path = g_npu_base_dir + "/" + raw_target;
        req_exe_path = g_exe_base_dir + "/" + raw_target + "/run.exe";
    }

    // Allow overriding exe path if user passed the -e flag
    if (!g_custom_exe.empty()) {
        req_exe_path = g_custom_exe;
    }

    std::string req_weights_path = g_weights_path;
    std::string req_workdir = g_workdir;

    static std::atomic<uint64_t> job_counter{0};
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

    std::string filename = "output_" + std::to_string(ms) + "_" + std::to_string(++job_counter) + ".png";
    std::string fullpath = (fs::path(g_output_dir) / filename).string();

    std::cout << "[INFO] Request received. Starting AI model (" << p.W << "x" << p.H << ")...\n";
    std::cout << "[INFO] Requested Model: " << p.model << " -> Resolving to Base: " << raw_target << "\n";
    std::cout << "[INFO] Using model weights: " << req_weights_path << "\n";
    std::cout << "[INFO] Using npu files: " << req_npu_files_path << "\n";
    std::cout << "[INFO] Using exe path: " << req_exe_path << "\n"; 
    std::cout << "[INFO] Input images count: " << p.input_images.size() << "\n";
    std::cout << "[INFO] Prompt: " << p.prompt << "\n";
    std::cout << "[INFO] Output path: " << fullpath << "\n";

    // Setup arguments dynamically
    std::vector<std::string> exec_args = {
        "--weights_path", req_weights_path,
        "--npu_files_path", req_npu_files_path,
        "--seed", std::to_string(p.seed),
        "--image_H", std::to_string(p.H),
        "--image_W", std::to_string(p.W),
        "--step", std::to_string(p.steps),
        "--prompt", p.prompt,
        "--output_path", fullpath
    };

    // Dynamically append all uploaded images so the NPU exe can find them (triggers edit mode inside EXE)
    for (const auto& img_path : p.input_images) {
        exec_args.push_back("--input_image"); 
        exec_args.push_back(img_path);
    }

    auto start_time = std::chrono::steady_clock::now();

    // Launch worker
    bp::child c(req_exe_path, bp::args(exec_args), bp::start_dir = req_workdir);
    c.wait();

    auto end_time = std::chrono::steady_clock::now();
    auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();

    if (c.exit_code() != 0) {
        std::cerr << "[ERROR] Worker failed with exit code " << c.exit_code() << "\n";
        throw std::runtime_error("worker failed with exit code " + std::to_string(c.exit_code()));
    }
    if (!fs::exists(fullpath)) {
        throw std::runtime_error("worker finished but output image was not created");
    }

    std::cout << "[INFO] Generation completed in " << elapsed_ms << " ms\n";
    std::cout << "[INFO] Waiting for next request\n";

    return fullpath;
}

// --------------------------------------------------
// Response helpers
// --------------------------------------------------
http::response<http::string_body>
make_json_response(http::status status, unsigned version, bool keep_alive, const json& body) {
    http::response<http::string_body> res{status, version};
    res.set(http::field::content_type, "application/json");
    res.keep_alive(keep_alive);
    res.body() = body.dump();
    res.prepare_payload();
    return res;
}

http::response<http::vector_body<char>>
make_image_response(unsigned version, bool keep_alive, std::vector<char>&& data, const std::string& mime) {
    http::response<http::vector_body<char>> res{http::status::ok, version};
    res.set(http::field::content_type, mime);
    res.keep_alive(keep_alive);
    res.body() = std::move(data);
    res.prepare_payload();
    return res;
}

// --------------------------------------------------
// Handle request
// --------------------------------------------------
http::message_generator
handle_request(http::request<http::string_body>&& req)
{
    const bool keep_alive = req.keep_alive();
    const std::string target = std::string(req.target());
    std::cout << "[REQ] " << req.method_string() << " " << target << "\n";
    
    try {
        if (req.method() == http::verb::get && target == "/health") {
            return make_json_response(http::status::ok, req.version(), keep_alive, json{{"status", "ok"}});
        }

        // if (req.method() == http::verb::get && target == "/v1/models") {
        //     json body = {
        //         {"object", "list"},
        //         {"data", json::array({ 
        //             {{"id", g_model_id}, {"object", "model"}, {"created", 0}, {"owned_by", "local"}},
        //             {{"id", g_model_id + ":edit"}, {"object", "model"}, {"created", 0}, {"owned_by", "local"}}
        //         })}
        //     };
        //     return make_json_response(http::status::ok, req.version(), keep_alive, body);
        // }
        if (req.method() == http::verb::get && target == "/v1/models") {
            json body = {
                {"object", "list"},
                {"data", json::array({ 
                    // Explicitly list your 3 perfect model names so the UI shows them cleanly
                    {{"id", "flux.2-klein-4B"}, {"object", "model"}, {"created", 0}, {"owned_by", "local"}},
                    {{"id", "flux.2-klein-4B-edit"}, {"object", "model"}, {"created", 0}, {"owned_by", "local"}},
                    {{"id", "z-image-turbo"}, {"object", "model"}, {"created", 0}, {"owned_by", "local"}}
                })}
            };
            return make_json_response(http::status::ok, req.version(), keep_alive, body);
        }

        if (req.method() == http::verb::get && target.rfind("/images/", 0) == 0) {
            std::string filename = target.substr(8);
            if (!is_safe_filename(filename)) return make_json_response(http::status::bad_request, req.version(), keep_alive, json{{"error", "invalid filename"}});
            std::string fullpath = g_output_dir + "/" + filename;
            if (!fs::exists(fullpath)) return make_json_response(http::status::not_found, req.version(), keep_alive, json{{"error", "image not found"}});
            
            auto data = read_binary_file(fullpath);
            std::string ext = fs::path(fullpath).extension().string();
            std::string mime = "image/png";
            if (ext == ".jpg" || ext == ".jpeg") mime = "image/jpeg";
            else if (ext == ".webp") mime = "image/webp";
            return make_image_response(req.version(), keep_alive, std::move(data), mime);
        }
        
        // STANDARD GENERATIONS ROUTE
        if (req.method() == http::verb::post && target == "/v1/images/generations") {
            GenParams params = parse_request(req.body());
            std::string response_format = get_response_format(req.body());
            std::string image_path;
            {
                std::lock_guard<std::mutex> lock(g_infer_mutex);
                image_path = run_worker(params);
            }

            auto data = read_binary_file(image_path);
            json item = { {"b64_json", base64_encode(data)}, {"revised_prompt", params.prompt} };

            if (!g_keep_images && response_format != "url") {
                std::error_code ec; fs::remove(image_path, ec);
            }

            json body = { {"created", static_cast<long long>(std::time(nullptr))}, {"data", json::array({item})} };
            return make_json_response(http::status::ok, req.version(), keep_alive, body);
        }

        // IMAGE EDITS ROUTE (MULTIPART/UPLOADS)
        if (req.method() == http::verb::post && target == "/v1/images/edits") {
            if (req[http::field::content_type].find("multipart/form-data") == std::string::npos) {
                return make_json_response(http::status::bad_request, req.version(), keep_alive, json{{"error", "Content-Type must be multipart/form-data"}});
            }

            GenParams params = parse_multipart_request(req);
            std::string image_path;
            {
                std::lock_guard<std::mutex> lock(g_infer_mutex);
                image_path = run_worker(params); 
            }

            auto data = read_binary_file(image_path);
            json item = { {"b64_json", base64_encode(data)}, {"revised_prompt", params.prompt} };

            // Cleanup generated output if requested
            if (!g_keep_images) {
                std::error_code ec; fs::remove(image_path, ec);
            }

            // Always cleanup the uploaded input images to save disk space
            for (const auto& in_img : params.input_images) {
                std::error_code ec;
                fs::remove(in_img, ec);
                std::cout << "[INFO] Cleaned up temp upload: " << in_img << "\n";
            }

            json body = { {"created", static_cast<long long>(std::time(nullptr))}, {"data", json::array({item})} };
            return make_json_response(http::status::ok, req.version(), keep_alive, body);
        }

        if (req.method() == http::verb::post && target == "/v1/chat/completions") {
            json body = {
                {"id", "chatcmpl-local"}, {"object", "chat.completion"}, {"created", static_cast<long long>(std::time(nullptr))}, {"model", g_model_id},
                {"choices", json::array({ {{"index", 0}, {"message", {{"role", "assistant"}, {"content", " "}}}, {"finish_reason", "stop"}} })},
                {"usage", {{"prompt_tokens", 0}, {"completion_tokens", 0}, {"total_tokens", 0}}}
            };
            return make_json_response(http::status::ok, req.version(), keep_alive, body);
        }

        if (target == "/v1/models" || target == "/v1/images/generations" || target == "/health" || target.rfind("/images/", 0) == 0) {
            return make_json_response(http::status::method_not_allowed, req.version(), keep_alive, json{{"error", "method not allowed"}});
        }
        
        return make_json_response(http::status::not_found, req.version(), keep_alive, json{{"error", "not found"}});
    }
    catch (std::exception& e) {
        return make_json_response(http::status::internal_server_error, req.version(), keep_alive, json{{"error", e.what()}});
    }
}

// --------------------------------------------------
// Session
// --------------------------------------------------
void do_session(tcp::socket socket) {
    beast::flat_buffer buffer;
    beast::error_code ec;
    
    for (;;) {
        // High capacity parser mapping (Allows up to 50MB for multipart edits)
        http::request_parser<http::string_body> parser;
        parser.body_limit(52428800); 

        http::read(socket, buffer, parser, ec);
        
        if (ec == http::error::end_of_stream) break;
        if (ec) { 
            std::cerr << "read error: " << ec.message() << "\n"; 
            return; 
        }
        
        http::request<http::string_body> req = parser.release();
        bool keep_alive = req.keep_alive();
        
        beast::write(socket, handle_request(std::move(req)), ec);
        
        if (ec) { 
            std::cerr << "write error: " << ec.message() << "\n"; 
            return; 
        }
        if (!keep_alive) break;
    }
    socket.shutdown(tcp::socket::shutdown_send, ec);
}

// --------------------------------------------------
// Main
// --------------------------------------------------
void print_usage(const char* prog_name) {
    std::cout << "Usage: " << prog_name << " [model_name] [options]\n\n"
              << "Available Models (examples):\n"
              << "  flux.2-klein-4B\n"
              << "  flux.2-klein-4B-edit\n"
              << "  z-image-turbo\n\n"
              << "Options:\n"
              << "  -w, --weights-path <path>      Path to model weights (Default: /opt/vigenflow/)\n"
              << "  -n, --npu-files-path <path>    Base directory for NPU files\n"
              << "  -o, --output-dir <path>        Output image directory\n"
              << "  -m, --model-id <id>            Model ID (Overrides positional argument)\n"
              << "  -p, --port <port>              Server port\n"
              << "  -e, --exe-path <path>          Worker executable path (Overrides automatic path)\n"
              << "  -d, --workdir <path>           Working directory\n"
              << "  -k, --keep-images <true/false> Keep generated images on disk (default: true)\n"
              << "  -h, --help                     Show this help message\n";
}

int main(int argc, char* argv[]) {
    bool output_dir_specified = false;

    try {
        for (int i = 1; i < argc; ++i) {
            std::string arg = argv[i];
    
            if (!arg.empty() && arg[0] != '-') {
                g_model_id = arg;
                continue; 
            }

            if (arg == "-h" || arg == "--help") { print_usage(argv[0]); return 0; }
            else if (arg == "-w" || arg == "--weights-path") { if (i + 1 < argc) g_weights_path = argv[++i]; else return 1; }
            else if (arg == "-n" || arg == "--npu-files-path") { if (i + 1 < argc) g_npu_base_dir = argv[++i]; else return 1; }
            else if (arg == "-o" || arg == "--output-dir") { if (i + 1 < argc) { g_output_dir = argv[++i]; output_dir_specified = true; } else return 1; }
            else if (arg == "-m" || arg == "--model-id") { if (i + 1 < argc) { g_model_id = argv[++i]; } else return 1; }
            else if (arg == "-p" || arg == "--port") { if (i + 1 < argc) { g_port = static_cast<unsigned short>(std::stoi(argv[++i])); g_public_base_url = "http://127.0.0.1:" + std::to_string(g_port); } else return 1; }
            else if (arg == "-e" || arg == "--exe-path") { if (i + 1 < argc) g_custom_exe = argv[++i]; else return 1; }
            else if (arg == "-d" || arg == "--workdir") { if (i + 1 < argc) g_workdir = argv[++i]; else return 1; }
            else if (arg == "-k" || arg == "--keep-images") { 
                if (i + 1 < argc) {
                    std::string val = argv[++i];
                    g_keep_images = (val == "true" || val == "1");
                } else return 1; 
            }
            else { std::cerr << "Unknown argument: " << arg << "\n\n"; print_usage(argv[0]); return 1; }
        }

        if (!g_keep_images && !output_dir_specified) g_output_dir = fs::temp_directory_path().string();
        ensure_output_dir();

        net::io_context ioc{1};
        tcp::acceptor acceptor{ioc, {net::ip::make_address("0.0.0.0"), g_port}};

        std::cout << "Server running on http://0.0.0.0:" << g_port << "\n";
        std::cout << "Weights Path: " << g_weights_path << "\n";
        std::cout << "NPU Base Dir: " << g_npu_base_dir << "\n"; 
        std::cout << "Executable Base Dir: " << g_exe_base_dir << "\n";
        std::cout << "Working Directory: " << g_workdir << "\n";
        std::cout << "Image Output Dir: " << g_output_dir << (!g_keep_images && !output_dir_specified ? " (Temporary)" : "") << "\n";
        std::cout << "Public Base URL: " << g_public_base_url << "\n";
        std::cout << "Model ID: " << g_model_id << "\n";

        for (;;) {
            tcp::socket socket{ioc};
            acceptor.accept(socket);
            std::thread{do_session, std::move(socket)}.detach();
        }
    }
    catch (std::exception& e) {
        std::cerr << "fatal error: " << e.what() << "\n";
        return 1;
    }
}